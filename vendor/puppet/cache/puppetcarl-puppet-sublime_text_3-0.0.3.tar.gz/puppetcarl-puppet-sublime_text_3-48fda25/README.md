# Sublime Text 3 Puppet Module for Boxen
## Forked from boxen/sublime_text_2

## Usage

```puppet
include sublime_text_3
```

## Required Puppet Modules

None.
